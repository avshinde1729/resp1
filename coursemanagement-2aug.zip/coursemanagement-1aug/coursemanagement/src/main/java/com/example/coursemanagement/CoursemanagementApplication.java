package com.example.coursemanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoursemanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoursemanagementApplication.class, args);
		System.out.println("Welcome to Course Management System");
	}

}
