package com.example.coursemanagement.controller;

import com.example.coursemanagement.model.Course;
import com.example.coursemanagement.model.Teacher;
import com.example.coursemanagement.service.CourseService;
import com.example.coursemanagement.service.TeacherService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import jakarta.persistence.EntityNotFoundException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/course")
public class CourseController {

    private static final Logger log = LoggerFactory.getLogger(CourseController.class);
    @Autowired
    private CourseService courseService;

    @Autowired
    private TeacherService teacherService;

    private static final Logger logger = LoggerFactory.getLogger(CourseController.class);

    @GetMapping("/all")
    public List<Course> getAllCourses() {
        return courseService.getAllCourses();
    }

    @GetMapping("/{courseId}")
    public Course getCourseById(@PathVariable Long courseId) {
        return courseService.getCourseById(courseId);
    }

    @PostMapping("/add")
    public Course addCourse(@RequestBody Course course) {
        // Fetch existing Teacher entity from the database using teacherId
        Teacher existingTeacher = teacherService.getTeacherById(course.getTeacher().getTeacherId());
        logger.info("============================existing Teacher =============================================");
        logger.info(String.valueOf(existingTeacher));

        if (existingTeacher != null) {
            // Set the fetched Teacher into the Course
            course.setTeacher(existingTeacher);

            // Save the Course
            return courseService.saveCourse(course);
        } else {
            // Handle case where teacher does not exist
            throw new EntityNotFoundException("Teacher not found with id: " + course.getTeacher().getTeacherId());
        }
    }

    @PutMapping("/update")
    public Course updateCourse(@RequestBody Course course) {
        // Fetch existing Teacher entity from the database using teacherId
        logger.info("in post req========================"+ course);
        logger.info("dsdsad");
        Teacher existingTeacher = teacherService.getTeacherById(course.getTeacher().getTeacherId());
        logger.info("============================existing Teacher =============================================");
        logger.info(String. valueOf(existingTeacher));

        if (existingTeacher != null) {
            // Set the fetched Teacher into the Course
            course.setTeacher(existingTeacher);

            // Save the updated Course
            return courseService.saveCourse(course);
        } else {
            // Handle case where teacher does not exist
            throw new EntityNotFoundException("Teacher not found with id: " + course.getTeacher().getTeacherId());
        }
    }

    @DeleteMapping("/{courseId}")
    public void deleteCourse(@PathVariable Long courseId) {
        courseService.deleteCourse(courseId);
    }

    // Other methods as needed
}
