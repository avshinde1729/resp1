////package com.example.coursemanagement.controller;
////
////import com.example.coursemanagement.model.Student;
////import com.example.coursemanagement.service.StudentService;
////import org.springframework.beans.factory.annotation.Autowired;
////import org.springframework.http.ResponseEntity;
////import org.springframework.web.bind.annotation.*;
////
////import java.util.List;
////
////@RestController
////@RequestMapping("/student")
////public class StudentController {
////
////    @Autowired
////    private StudentService studentService;
////
////    @GetMapping("/all")
////    public List<Student> getAllStudents() {
////        return studentService.getAllStudents();
////    }
////
////    @GetMapping("/{studentId}")
////    public Student getStudentById(@PathVariable Long studentId) {
////        return studentService.getStudentById(studentId);
////    }
////
////    @PostMapping("/add")
////    public ResponseEntity<?> addStudent(@RequestBody Student student) {
////        Student savedStudent = studentService.saveStudent(student);
////        return ResponseEntity.ok(savedStudent);
////    }
////
////    @PutMapping("/update")
////    public ResponseEntity<?> updateStudent(@RequestBody Student student) {
////        Student updatedStudent = studentService.saveStudent(student);
////        return ResponseEntity.ok(updatedStudent);
////    }
////
////    @DeleteMapping("/{studentId}")
////    public ResponseEntity<?> deleteStudent(@PathVariable Long studentId) {
////        studentService.deleteStudent(studentId);
////        return ResponseEntity.noContent().build();
////    }
////=======================================================Below code is with ManyToMany relationship
//
//
//
//package com.example.coursemanagement.controller;
//
//import com.example.coursemanagement.model.Course;
//import com.example.coursemanagement.model.Student;
//import com.example.coursemanagement.service.StudentService;
//import com.example.coursemanagement.service.CourseService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//
//@RestController
//@RequestMapping("/student")
//public class StudentController {
//
//    @Autowired
//    private StudentService studentService;
//
//    @Autowired
//    private CourseService courseService;
//
//    @GetMapping("/all")
//    public List<Student> getAllStudents() {
//        return studentService.getAllStudents();
//    }
//
//    @GetMapping("/{studentId}")
//    public Student getStudentById(@PathVariable Long studentId) {
//        return studentService.getStudentById(studentId);
//    }
//
//    @PostMapping("/add")
//    public ResponseEntity<?> addStudent(@RequestBody Student student) {
//        Student savedStudent = studentService.saveStudent(student);
//        return ResponseEntity.ok(savedStudent);
//    }
//
//    @PutMapping("/update")
//    public ResponseEntity<?> updateStudent(@RequestBody Student student) {
//        Student updatedStudent = studentService.saveStudent(student);
//        return ResponseEntity.ok(updatedStudent);
//    }
//
//    @DeleteMapping("/{studentId}")
//    public ResponseEntity<?> deleteStudent(@PathVariable Long studentId) {
//        studentService.deleteStudent(studentId);
//        return ResponseEntity.noContent().build();
//    }
//
//    @PostMapping("/{studentId}/enroll")
//    public ResponseEntity<?> enrollStudentToCourse(@PathVariable Long studentId, @RequestBody Long courseId) {
//        Student student = studentService.getStudentById(studentId);
//        Course course = courseService.getCourseById(courseId);
//
//        if (student == null || course == null) {
//            return ResponseEntity.badRequest().body("Student or Course not found");
//        }
//
//        student.getCourses().add(course);
//        studentService.saveStudent(student);  // Ensure you save the updated student
//
//        return ResponseEntity.ok("Student enrolled successfully");
//    }
//
//    @PostMapping("/{studentId}/unenroll")
//    public ResponseEntity<?> unenrollStudentFromCourse(@PathVariable Long studentId, @RequestBody Long courseId) {
//        Student student = studentService.getStudentById(studentId);
//        Course course = courseService.getCourseById(courseId);
//
//        if (student == null || course == null) {
//            return ResponseEntity.badRequest().body("Student or Course not found");
//        }
//
//        student.getCourses().remove(course);
//        studentService.saveStudent(student);  // Ensure you save the updated student
//
//        return ResponseEntity.ok("Student unenrolled successfully");
//    }
//}



//=================================================== WITH MANY TO MANY =====================================================================


//package com.example.coursemanagement.controller;
//
//import com.example.coursemanagement.model.Course;
//import com.example.coursemanagement.model.Student;
//import com.example.coursemanagement.service.StudentService;
//import com.example.coursemanagement.service.CourseService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//
//@RestController
//@RequestMapping("/student")
//public class StudentController {
//
//    @Autowired
//    private StudentService studentService;
//
//    @Autowired
//    private CourseService courseService;
//
//    @GetMapping("/all")
//    public List<Student> getAllStudents() {
//        return studentService.getAllStudents();
//    }
//
//    @GetMapping("/{studentId}")
//    public Student getStudentById(@PathVariable Long studentId) {
//        return studentService.getStudentById(studentId);
//    }
//
//    @PostMapping("/add")
//    public ResponseEntity<?> addStudent(@RequestBody Student student) {
//        Student savedStudent = studentService.saveStudent(student);
//        return ResponseEntity.ok(savedStudent);
//    }
//
//    @PutMapping("/update")
//    public ResponseEntity<?> updateStudent(@RequestBody Student student) {
//        Student updatedStudent = studentService.saveStudent(student);
//        return ResponseEntity.ok(updatedStudent);
//    }
//
//    @DeleteMapping("/{studentId}")
//    public ResponseEntity<?> deleteStudent(@PathVariable Long studentId) {
//        studentService.deleteStudent(studentId);
//        return ResponseEntity.noContent().build();
//    }
//
//    @PostMapping("/{studentId}/enroll")
//    public ResponseEntity<?> enrollStudentToCourse(@PathVariable Long studentId, @RequestBody Long courseId) {
//        Student student = studentService.getStudentById(studentId);
//        Course course = courseService.getCourseById(courseId);
//
//        if (student == null || course == null) {
//            return ResponseEntity.badRequest().body("Student or Course not found");
//        }
//
//        student.getCourses().add(course);
//        studentService.saveStudent(student);  // Ensure you save the updated student
//
//        return ResponseEntity.ok("Student enrolled successfully");
//    }
//
//    @PostMapping("/{studentId}/unenroll")
//    public ResponseEntity<?> unenrollStudentFromCourse(@PathVariable Long studentId, @RequestBody Long courseId) {
//        Student student = studentService.getStudentById(studentId);
//        Course course = courseService.getCourseById(courseId);
//
//        if (student == null || course == null) {
//            return ResponseEntity.badRequest().body("Student or Course not found");
//        }
//
//        student.getCourses().remove(course);
//        studentService.saveStudent(student);  // Ensure you save the updated student
//
//        return ResponseEntity.ok("Student unenrolled successfully");
//    }
//}




package com.example.coursemanagement.controller;

import com.example.coursemanagement.model.Course;
import com.example.coursemanagement.model.Student;
import com.example.coursemanagement.service.StudentService;
import com.example.coursemanagement.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/student")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @Autowired
    private CourseService courseService; // Add CourseService for course management

    @GetMapping("/all")
    public ResponseEntity<List<Student>> getAllStudents() {
        List<Student> students = studentService.getAllStudents();
        return ResponseEntity.ok(students);
    }

    @GetMapping("/{studentId}")
    public ResponseEntity<Student> getStudentById(@PathVariable Long studentId) {
        Student student = studentService.getStudentById(studentId);
        if (student == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(student);
    }

    @PostMapping("/add")
    public ResponseEntity<Student> addStudent(@RequestBody Student student) {
        Student savedStudent = studentService.saveStudent(student);
        return ResponseEntity.ok(savedStudent);
    }

    @PutMapping("/update")
    public ResponseEntity<Student> updateStudent(@RequestBody Student student) {
        Student updatedStudent = studentService.saveStudent(student);
        return ResponseEntity.ok(updatedStudent);
    }

    @DeleteMapping("/{studentId}")
    public ResponseEntity<Void> deleteStudent(@PathVariable Long studentId) {
        studentService.deleteStudent(studentId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{studentId}/courses")
    public ResponseEntity<List<Course>> getCoursesByStudentId(@PathVariable Long studentId) {
        List<Course> courses = studentService.getCoursesByStudentId(studentId);
        return ResponseEntity.ok(courses);
    }

//    @PostMapping("/{studentId}/courses/{courseId}/enroll")
//    public ResponseEntity<String> enrollStudentInCourse(@PathVariable Long studentId, @PathVariable Long courseId) {
//        try {
//            studentService.enrollStudentInCourse(studentId, courseId);
//            return ResponseEntity.ok("Student enrolled in course successfully.");
//        } catch (Exception e) {
//            return ResponseEntity.badRequest().body(e.getMessage());
//        }
//    }
//
//    @DeleteMapping("/{studentId}/courses/{courseId}/unenroll")
//    public ResponseEntity<String> unenrollStudentFromCourse(@PathVariable Long studentId, @PathVariable Long courseId) {
//        try {
//            studentService.unenrollStudentFromCourse(studentId, courseId);
//            return ResponseEntity.ok("Student unenrolled from course successfully.");
//        } catch (Exception e) {
//            return ResponseEntity.badRequest().body(e.getMessage());
//        }
//    }
}
