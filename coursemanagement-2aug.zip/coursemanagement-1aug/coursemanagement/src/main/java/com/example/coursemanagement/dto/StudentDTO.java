package com.example.coursemanagement.dto;

import java.util.Set;

public class StudentDTO {
    private Long studentId;
    private String username;
    private String firstName;
    private String lastName;
    private String email;
    private String mobileNo;
    private String address;
    private String classDivision;
    private Set<Long> courseIds; // Only include course IDs


    // Getters and setters
    public Long getStudentId() { return studentId; }
    public void setStudentId(Long studentId) { this.studentId = studentId; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getMobileNo() { return mobileNo; }
    public void setMobileNo(String mobileNo) { this.mobileNo = mobileNo; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getClassDivision() { return classDivision; }
    public void setClassDivision(String classDivision) { this.classDivision = classDivision; }
    public Set<Long> getCourseIds() { return courseIds; }
    public void setCourseIds(Set<Long> courseIds) { this.courseIds = courseIds; }
}
