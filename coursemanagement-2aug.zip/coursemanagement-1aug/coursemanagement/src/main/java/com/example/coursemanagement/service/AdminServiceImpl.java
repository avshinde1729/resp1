package com.example.coursemanagement.service;

import com.example.coursemanagement.exception.ValidationException;
import com.example.coursemanagement.model.Admin;
import com.example.coursemanagement.repository.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private AdminRepository adminRepository;

    @Override
    public List<Admin> getAllAdmins() {
        return adminRepository.findAll();
    }

    @Override
    public Admin getAdminById(Long adminId) {
        if (adminId == null || adminId <= 0) {
            throw new ValidationException("Invalid admin ID: " + adminId);
        }
        Optional<Admin> adminOptional = adminRepository.findById(adminId);
        return adminOptional.orElse(null);
    }

    @Override
    public Admin saveAdmin(Admin admin) {
        validateAdmin(admin);
        Admin existingAdmin = adminRepository.findByUsername(admin.getUsername());
        if (existingAdmin != null && !existingAdmin.getAdminId().equals(admin.getAdminId())) {
            throw new ValidationException("Username already exists");
        }
        return adminRepository.save(admin);
    }

    @Override
    public void deleteAdmin(Long adminId) {
        if (adminId == null || adminId <= 0) {
            throw new ValidationException("Invalid admin ID: " + adminId);
        }
        if (!adminRepository.existsById(adminId)) {
            throw new ValidationException("Admin not found with ID: " + adminId);
        }
        adminRepository.deleteById(adminId);
    }




    private void validateAdmin(Admin admin) {
        if (admin == null) {
            throw new ValidationException("Admin cannot be null");
        }
        if (admin.getUsername() == null || admin.getUsername().isEmpty()) {
            throw new ValidationException("Username is mandatory");
        }
        if (admin.getUsername().length() < 3 || admin.getUsername().length() > 50) {
            throw new ValidationException("Username must be between 3 and 50 characters");
        }
        if (admin.getPassword() == null || admin.getPassword().isEmpty()) {
            throw new ValidationException("Password is mandatory");
        }
        if (admin.getPassword().length() < 6 || admin.getPassword().length() > 100) {
            throw new ValidationException("Password must be between 6 and 100 characters");
        }
    }
}
