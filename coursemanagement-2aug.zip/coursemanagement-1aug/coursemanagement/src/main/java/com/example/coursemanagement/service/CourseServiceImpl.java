//package com.example.coursemanagement.service;
//
//import com.example.coursemanagement.exception.ValidationException;
//import com.example.coursemanagement.model.Course;
//import com.example.coursemanagement.model.Teacher;
//import com.example.coursemanagement.repository.CourseRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//import java.util.Optional;
//
//@Service
//public class CourseServiceImpl implements CourseService {
//
//    @Autowired
//    private CourseRepository courseRepository;
//
//    @Autowired
//    private TeacherService teacherService;
//
//    @Override
//    public List<Course> getAllCourses() {
//        return courseRepository.findAll();
//    }
//
//    @Override
//    public Course getCourseById(Long courseId) {
//        if (courseId == null || courseId <= 0) {
//            throw new ValidationException("Invalid course ID: " + courseId);
//        }
//        Optional<Course> courseOptional = courseRepository.findById(courseId);
//        return courseOptional.orElse(null);
//    }
//
//    @Override
//    public Course saveCourse(Course course) {
//        validateCourse(course);
//        return courseRepository.save(course);
//    }
//
//    @Override
//    public void deleteCourse(Long courseId) {
//        if (courseId == null || courseId <= 0) {
//            throw new ValidationException("Invalid course ID: " + courseId);
//        }
//        if (!courseRepository.existsById(courseId)) {
//            throw new ValidationException("Course not found with ID: " + courseId);
//        }
//        courseRepository.deleteById(courseId);
//    }
//
//    private void validateCourse(Course course) {
//        if (course == null) {
//            throw new ValidationException("Course cannot be null");
//        }
//        if (course.getCourseName() == null || course.getCourseName().isEmpty()) {
//            throw new ValidationException("Course name cannot be null or empty");
//        }
//        if (course.getTeacher() == null || course.getTeacher().getTeacherId() == null) {
//            throw new ValidationException("Teacher information is required");
//        }
//
//        Teacher teacher = teacherService.getTeacherById(course.getTeacher().getTeacherId());
//        if (teacher == null) {
//            throw new ValidationException("Teacher not found with ID: " + course.getTeacher().getTeacherId());
//        }
//        course.setTeacher(teacher);
//    }
//}




//===================================== WITH MANY TO MANY RELATIONSHIP ==========================================================


package com.example.coursemanagement.service;

import com.example.coursemanagement.exception.ValidationException;
import com.example.coursemanagement.model.Course;
import com.example.coursemanagement.model.Teacher;
import com.example.coursemanagement.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CourseServiceImpl implements CourseService {

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private TeacherService teacherService;

    @Override
    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }

    @Override
    public Course getCourseById(Long courseId) {
        if (courseId == null || courseId <= 0) {
            throw new ValidationException("Invalid course ID: " + courseId);
        }
        Optional<Course> courseOptional = courseRepository.findById(courseId);
        return courseOptional.orElse(null);
    }

    @Override
    public Course saveCourse(Course course) {
        validateCourse(course);
        return courseRepository.save(course);
    }

    @Override
    public void deleteCourse(Long courseId) {
        if (courseId == null || courseId <= 0) {
            throw new ValidationException("Invalid course ID: " + courseId);
        }
        if (!courseRepository.existsById(courseId)) {
            throw new ValidationException("Course not found with ID: " + courseId);
        }
        courseRepository.deleteById(courseId);
    }

    private void validateCourse(Course course) {
        if (course == null) {
            throw new ValidationException("Course cannot be null");
        }
        if (course.getCourseName() == null || course.getCourseName().isEmpty()) {
            throw new ValidationException("Course name cannot be null or empty");
        }
        if (course.getTeacher() == null || course.getTeacher().getTeacherId() == null) {
            throw new ValidationException("Teacher information is required");
        }

        Teacher teacher = teacherService.getTeacherById(course.getTeacher().getTeacherId());
        if (teacher == null) {
            throw new ValidationException("Teacher not found with ID: " + course.getTeacher().getTeacherId());
        }
        course.setTeacher(teacher);
    }
}
