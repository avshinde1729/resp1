//package com.example.coursemanagement.service;
//
//import com.example.coursemanagement.model.Student;
//
//import java.util.List;
//
//public interface StudentService {
//
//    List<Student> getAllStudents();
//
//    Student getStudentById(Long studentId);
//
//    Student saveStudent(Student student);
//
//    void deleteStudent(Long studentId);
//
//    // Other methods as needed
//}



package com.example.coursemanagement.service;

import com.example.coursemanagement.model.Course;
import com.example.coursemanagement.model.Student;

import java.util.List;

public interface StudentService {

    List<Student> getAllStudents();

    Student getStudentById(Long studentId);

    Student saveStudent(Student student);

    void deleteStudent(Long studentId);

//    void enrollStudentToCourse(Long studentId, Long courseId);
    void unenrollStudentFromCourse(Long studentId, Long courseId);

    List<Course> getCoursesByStudentId(Long studentId);

    void enrollStudentInCourse(Long studentId, Long courseId);
}
