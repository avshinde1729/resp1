package com.example.coursemanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoursemanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
