
CREATE DATABASE IF NOT EXISTS cms_257;


\c cms_257;

CREATE TABLE admin (
    admin_id BIGSERIAL PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL
);

CREATE TABLE teacher (
    teacher_id BIGSERIAL PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    mobile_no VARCHAR(20),
    address VARCHAR(255)
);

CREATE TABLE student (
    student_id BIGSERIAL PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    mobile_no VARCHAR(20),
    address VARCHAR(255),
    class_division VARCHAR(50)
);

CREATE TABLE course (
    course_id BIGSERIAL PRIMARY KEY,
    course_name VARCHAR(255) NOT NULL,
    description TEXT,
    duration VARCHAR(50),
    assigned_date DATE,
    end_date DATE,
    teacher_id BIGINT,
    FOREIGN KEY (teacher_id) REFERENCES teacher(teacher_id)
);

CREATE TABLE student_course (
    student_id BIGINT,
    course_id BIGINT,
    PRIMARY KEY (student_id, course_id),
    FOREIGN KEY (student_id) REFERENCES student(student_id),
    FOREIGN KEY (course_id) REFERENCES course(course_id)
);



INSERT INTO admin (username, password)
VALUES ('admin1', 'admin1password');


INSERT INTO teacher (username, password, first_name, last_name, email, mobile_no, address)
VALUES ('teacher1', 'teacher1password', 'John', 'Doe', 'john.doe@example.com', '+1234567890', '123 Teacher St, City');

-- Students
INSERT INTO student (username, password, first_name, last_name, email, mobile_no, address, class_division)
VALUES
    ('student1', 'student1password', 'Alice', 'Smith', 'alice.smith@example.com', '+1987654321', '456 Student St, City', 'Grade 10'),
    ('student2', 'student2password', 'Bob', 'Johnson', 'bob.johnson@example.com', '+1654321897', '789 Learner St, Town', 'Grade 11');

-- Courses
INSERT INTO course (course_name, description, duration, assigned_date, end_date, teacher_id)
VALUES
    ('Mathematics', 'Advanced math concepts', '1 year', '2024-01-01', '2024-12-31', 1),
    ('History', 'World history overview', '1 semester', '2024-02-15', '2024-06-30', 1);

-- Student-Course Associations
INSERT INTO student_course (student_id, course_id)
VALUES
    (1, 1),  -- Alice enrolled in Mathematics
    (1, 2),
    (2, 2);  -- Bob enrolled in History;

