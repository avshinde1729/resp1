package com.myProject.crud.controller;

import com.myProject.crud.dto.EmployeeDto;
import com.myProject.crud.service.EmployeeService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@AllArgsConstructor
@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    private EmployeeService employeeService;

    // Building Add Employee RestApi

    @PostMapping
    public ResponseEntity<EmployeeDto> createEmployee(@RequestBody EmployeeDto employeeDto) {
        EmployeeDto savedEmployee = employeeService.createEmployee(employeeDto);
        return new ResponseEntity<>(savedEmployee, HttpStatus.CREATED);

    }

    // Building get employee
    @GetMapping("{id}")
    public ResponseEntity<EmployeeDto> getEmployeeById(@PathVariable("id") Long employeeId) {
        EmployeeDto employeeDto = employeeService.getEmployeeById(employeeId);
        return ResponseEntity.ok(employeeDto);
    }

    // Get all employee

    @GetMapping
    public ResponseEntity<List<EmployeeDto>> getAllEmployees() {
        List<EmployeeDto> employees = employeeService.getAllEmployees();
        return ResponseEntity.ok(employees);
    }


    // update employee
    @PutMapping("{id}")
    public Object updateEmployee(@PathVariable("id") Long employeeId,
                                 @RequestBody EmployeeDto updateEmployee) {
        return employeeService.updateEmployee(employeeId, updateEmployee);
//        EmployeeDto employeeDto = (EmployeeDto) employeeService.updateEmployee(employeeId,updateEmployee);
//        if (employeeDto==null){
//            return "Validation failed";
//        }
//        return ResponseEntity.ok(employeeDto);
    }


    //delete employee
    @DeleteMapping("{id}")
    public ResponseEntity<String> deleteEmployee(@PathVariable("id") Long employeeId) {
        employeeService.deleteEmployee(employeeId);
        return ResponseEntity.ok("Employee Delete Successfully");
    }

}
