package com.myProject.crud.service.impl;

import com.myProject.crud.dto.EmployeeDto;
import com.myProject.crud.entity.Employee;
import com.myProject.crud.exception.ResourseNotFoundException;
import com.myProject.crud.mapper.EmployeeMapper;
import com.myProject.crud.repository.EmployeeRepository;
import com.myProject.crud.service.EmployeeService;
import com.myProject.crud.validate.EmployeeValidator;
import com.myProject.crud.validate.ValidationResult;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    private EmployeeRepository employeeRepository;


    @Override
    public EmployeeDto createEmployee(EmployeeDto employeeDto) {

        Employee employee = EmployeeMapper.mapToEmployee(employeeDto);
        Employee savedEmployee = employeeRepository.save(employee);

        return EmployeeMapper.mapToEmployeeDto(savedEmployee);
    }

    @Override
    public EmployeeDto getEmployeeById(Long employeeId) {
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new ResourseNotFoundException("Employee is not exist with given id : " + employeeId));
        return EmployeeMapper.mapToEmployeeDto(employee);
    }

    @Override
    public List<EmployeeDto> getAllEmployees() {
        List<Employee> employees = employeeRepository.findAll();
        return employees.stream().map((employee) -> EmployeeMapper.mapToEmployeeDto(employee))
                .collect(Collectors.toList());
    }

    @Override
    public Object updateEmployee(Long employeeId, EmployeeDto updateEmployee) {
        EmployeeValidator validator = new EmployeeValidator();
        ValidationResult result = validator.validateEmployee(updateEmployee.getId(), updateEmployee.getFname(), updateEmployee.getLname(), updateEmployee.getEmail());

        if (result.hasErrors()) {
            System.out.println("Validation failed:");
            for (String error : result.getErrors()) {
                System.out.println(error);
            }
            return result;
        } else {
            System.out.println("Validation successful!");

            Employee employee = employeeRepository.findById(employeeId).orElseThrow(
                    () -> new ResourseNotFoundException("Employee not exists with given id : " + employeeId)
            );

            employee.setFname(updateEmployee.getFname());
            employee.setLname(updateEmployee.getLname());
            employee.setEmail(updateEmployee.getEmail());

            Employee updateEmployeeObj = employeeRepository.save(employee);

            return EmployeeMapper.mapToEmployeeDto(updateEmployeeObj);
        }
    }

    @Override
    public void deleteEmployee(Long employeeId) {
        Employee employee = employeeRepository.findById(employeeId).orElseThrow(
                () -> new ResourseNotFoundException("Employee not exists with given id : " + employeeId)
        );

        employeeRepository.deleteById(employeeId);

    }


}
