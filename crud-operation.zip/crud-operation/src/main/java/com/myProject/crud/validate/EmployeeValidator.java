package com.myProject.crud.validate;

import java.util.regex.Pattern;

public class EmployeeValidator {

    private static final String NAME_REGEX = "^[a-zA-Z]{2,50}$";
    private static final String EMAIL_REGEX = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";

    public boolean validateId(Long id) {
        return id != null && id > 0;
    }

    public boolean validateName(String name) {
        return name != null && !name.trim().isEmpty() && name.matches(NAME_REGEX);
    }

    public boolean validateEmail(String email) {
        return email != null && !email.trim().isEmpty() && email.matches(EMAIL_REGEX);
    }

    public ValidationResult validateEmployee(Long id, String fname, String lname, String email) {
        ValidationResult result = new ValidationResult();

        if (!validateId(id)) {
            result.addError("Invalid ID: must be a positive number.");
        }

        if (!validateName(fname)) {
            result.addError("Invalid first name: must be between 2 and 50 alphabetic characters.");
        }

        if (!validateName(lname)) {
            result.addError("Invalid last name: must be between 2 and 50 alphabetic characters.");
        }

        if (!validateEmail(email)) {
            result.addError("Invalid email address.");
        }

        return result;
    }
}
